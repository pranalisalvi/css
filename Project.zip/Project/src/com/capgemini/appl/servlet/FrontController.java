package com.capgemini.appl.servlet;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.IUniversityService;
import com.capgemini.appl.service.UniversityServiceImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private String nextJspString;
	String msg = null;
	private ServletContext ctxContext;
	IUniversityService service;
	private RequestDispatcher dispatch;
	private String nxtJsp;

	private Application appl;
	public FrontController() {
		super();
		service = new UniversityServiceImpl();
		appl=new Application();
	}

	public void init() throws ServletException {

	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getServletPath();
		switch (command) {
		case "/showDetails.do": {
			List<ProgramsOffered> myList=null;
			try {
				myList=service.showAll();
			} catch (UniversityAdmissionException e) {
				
				e.printStackTrace();
			}
			request.setAttribute("data",myList);
			nxtJsp="programInformation.jsp";
			break;
		}
		case "/getid.do": {
			System.out.println("In getid do");
			String name=request.getQueryString();
			try {
			int id=service.getProgramId(name);
				System.out.println(name);
				request.setAttribute("id", id);
				
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
				nxtJsp="Application.jsp";
			
			break;
		}
		case "/viewstatus.do":{
			
			String id=request.getParameter("application_id");
			System.out.println(id);
			int id1=Integer.parseInt(id);
			
			try {
				System.out.println("In try");
				Application status=service.showStatus(id1);
				System.out.println(status);
				if(status.getApplication_id()==0)
				{
					request.setAttribute("msg","Applicant not found");
					nxtJsp="ViewStatus.jsp";
				}
				else{
				request.setAttribute("status",status);
				nxtJsp="status.jsp";
				}
				
			} catch (UniversityAdmissionException e) {
				
				e.printStackTrace();
			}
			
			break;
		
		}
		case "/insert.do" :{
int id=0;
			try {
				
				try {
					id = service.getApplicationId();
				} catch (UniversityAdmissionException e1) {
				
					e1.printStackTrace();
				}
				
				String name=request.getParameter("name");
						
				String dob=request.getParameter("dob");
				java.util.Date date=new SimpleDateFormat("dd-MM-yyyy").parse(dob);
				java.sql.Date sqldate=new java.sql.Date(date.getTime());
				//appl.setDate_of_birth(sqldate);
				
				String hqual=request.getParameter("hqual");
				int marks=Integer.parseInt(request.getParameter("marks"));
				String goal=request.getParameter("goal");
				String email=request.getParameter("email");
				String sid=request.getParameter("schedulprogram");
				String status=request.getParameter("status");
				/*
				String interviewdate=request.getParameter("interviewdate");
				java.util.Date date1=new SimpleDateFormat("dd-MM-yyyy").parse(interviewdate);
				java.sql.Date sqldate1=new java.sql.Date(date1.getTime());*/
				//appl.setDate_Of_Interview(sqldate1);
				
				//service.addApplicant(id,name,dob,sqldate,hqual,marks,goal,email,sid,status,sqldate1);
				
				appl.setApplication_id(id);
				appl.setFull_name(name);
				appl.setDate_of_birth(sqldate);
				appl.setHighest_qualification(hqual);
				appl.setMarks_obtained(marks);
				appl.setGoals(goal);
				appl.setEmail_id(email);
				appl.setScheduled_program_id(sid);
				appl.setStatus(status);
				
				
				
				try {
					int id1=service.addApplicant(appl);
					request.setAttribute("Id",id1);
					nxtJsp="success.jsp";
				} catch (UniversityAdmissionException e) {
					
					e.printStackTrace();
				}
			} catch (NumberFormatException e) {
			
				e.printStackTrace();
			} catch (ParseException e) {
			
				e.printStackTrace();
			}
			
			break;
		}

		}
		dispatch = request.getRequestDispatcher(nxtJsp);
		dispatch.forward(request, response);
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	public void destroy() {
	}

}
