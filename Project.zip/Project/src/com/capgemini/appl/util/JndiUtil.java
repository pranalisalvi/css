package com.capgemini.appl.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.naming.Context;

import com.capgemini.appl.exception.UniversityAdmissionException;




	public class JndiUtil {
		private DataSource datasource;

		public JndiUtil() throws UniversityAdmissionException {
			try {
				Context ctx = new InitialContext();// get reference to rwemote
													// jndi//Context ans
													// initialContext r jndi
													// specific
				datasource = (DataSource) ctx.lookup("java:/OracleDS1");
				
			} catch (NamingException e) {

				e.printStackTrace();
				throw new UniversityAdmissionException("Failed to get JNDI Context",e);
			}
		}
		public Connection getConnection() throws SQLException {
			return datasource.getConnection();
		}

		//@Override
		/*protected void finalize() throws Throwable {
			datasource.close();
			super.finalize();
		}*/

	}