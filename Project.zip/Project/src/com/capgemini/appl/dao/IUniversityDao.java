package com.capgemini.appl.dao;

import java.util.List;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;

public interface IUniversityDao {
	public int getApplicationId()throws UniversityAdmissionException;
	public List<ProgramsOffered> showAll() throws UniversityAdmissionException;
	public int addApplicant(Application appl) throws UniversityAdmissionException;
	public Application showStatus(int application_id) throws UniversityAdmissionException;
	public int getProgramId(String programName)throws UniversityAdmissionException;
}
