package com.capgemini.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.util.JndiUtil;



public class UniversityDaoImpl  implements IUniversityDao{
	Connection conn;
	PreparedStatement pstm;
	JndiUtil util;

	public UniversityDaoImpl() {
		try {
			util =new JndiUtil();
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public int getApplicationId() throws UniversityAdmissionException {
		int a=0;
		try {
			conn = util.getConnection();
			String query="SELECT application_id.nextval from dual";
			pstm = conn.prepareStatement(query);
			ResultSet rs = pstm.executeQuery();
			while(rs.next()){
			a=rs.getInt(1);
			}
			System.out.println(a);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return a;
		
	}
	
	public List<ProgramsOffered> showAll() throws UniversityAdmissionException {
		Connection conn=null;
		PreparedStatement pstm=null;
		List<ProgramsOffered> myProg=new ArrayList<ProgramsOffered>();
		String query="Select ProgramName,description,applicant_eligibility,duration,degree_certificate_offered from Programs_Offered";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			ResultSet rst=pstm.executeQuery();
			while(rst.next()){
				ProgramsOffered p=new ProgramsOffered();
				p.setProgramName(rst.getString("ProgramName"));
				p.setDescription(rst.getString("description"));
				p.setApplicant(rst.getString("applicant_eligibility"));
				p.setDuration(rst.getInt("duration"));
				p.setDegree_certificate_offered(rst.getString("degree_certificate_offered"));
			
				myProg.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UniversityAdmissionException("Problem in show");
		}finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return myProg;
	}

	@Override
	public int addApplicant(Application appl) throws UniversityAdmissionException {
		int status=0;
		String query="Insert into Application values(?,?,?,?,?,?,?,?,?)";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1, appl.getApplication_id());
			pstm.setString(2, appl.getFull_name());
			pstm.setDate(3, appl.getDate_of_birth());
			pstm.setString(4, appl.getHighest_qualification());
			pstm.setInt(5, appl.getMarks_obtained());
			pstm.setString(6, appl.getGoals());
			pstm.setString(7, appl.getEmail_id());
			pstm.setString(8, appl.getScheduled_program_id());
			pstm.setString(9, "applied");
			
			
			
			
			status=pstm.executeUpdate();
			if(status==1){
				System.out.println("Data Inserted");
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new UniversityAdmissionException("Problem in Exception");
		}finally{
			try {
				if(pstm!=null){
				pstm.close();
				}
				if(conn!=null){
				conn.close();
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return appl.getApplication_id();
		
	}

	@Override
	public Application showStatus(int application_id)
			throws UniversityAdmissionException {
		Application appl=new Application();
		String status=null;
		String query="SELECT full_name,Scheduled_program_id,status FROM Application WHERE Application_id=?";
		try {
		
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,application_id);
			ResultSet rs =pstm.executeQuery();
			while(rs.next()){
			appl.setApplication_id(application_id);
			appl.setFull_name(rs.getString("full_name"));
			appl.setScheduled_program_id(rs.getString("Scheduled_program_id"));
			appl.setStatus(rs.getString("status"));
			}
			System.out.println(status);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return appl;
	}
	public int getProgramId(String programName)
			throws UniversityAdmissionException {
		ProgramsScheduled ps=new ProgramsScheduled();
		String status=null;
	
	
		String query="SELECT Scheduled_program_id FROM Programs_Scheduled WHERE ProgramName=?";
		try {
		
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,programName);
			ResultSet rs =pstm.executeQuery();
			System.out.println(rs);
		
			ps.setScheduled_program_id(Integer.parseInt(rs.getString("Scheduled_program_id")));
			
			System.out.println(status);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ps.getScheduled_program_id();
	}

}
