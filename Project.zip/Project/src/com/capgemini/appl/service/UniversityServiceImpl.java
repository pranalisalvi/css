package com.capgemini.appl.service;

import java.util.List;

import com.capgemini.appl.dao.IUniversityDao;
import com.capgemini.appl.dao.UniversityDaoImpl;
import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;

public class UniversityServiceImpl implements IUniversityService {
private IUniversityDao dao;
	public UniversityServiceImpl() {
		dao=new UniversityDaoImpl();
	}

	@Override
	public int getApplicationId() throws UniversityAdmissionException {
	
		return dao.getApplicationId();
	}

	@Override
	public List<ProgramsOffered> showAll() throws UniversityAdmissionException {
		
		return dao.showAll();
	}

	@Override
	public int addApplicant(Application appl) throws UniversityAdmissionException {
		
		return dao.addApplicant(appl);
	}

	@Override
	public Application showStatus(int application_id)
			throws UniversityAdmissionException {
	
		return dao.showStatus(application_id);
	}

	@Override
	public int getProgramId(String programName)throws UniversityAdmissionException {
	
		return dao.getProgramId(programName);
	}

}
